"""
Note.com 自動投稿用スクリプト (ChatGPT全自動対応版)

【使い方】
以下の「設定」部分をご自身のアカウント情報やChatGPTへのお題（プロンプト）に書き換えて実行するか、
または環境変数 (GitHub Secrets等) に設定して自動運転させてください。
"""
import os
import sys
import time
from dotenv import load_dotenv

# API関連
from openai import OpenAI

# Selenium関連
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service

load_dotenv()

# ====================================
# [ 設定 / Credentials ]
# GitHub Actions の Secrets 等の「環境変数」が設定されている場合はそちらを優先します。
# 個人のPCで手動実行する場合は、こちらの "" の中を直接書き換えてください。
# ====================================
NOTE_EMAIL = os.getenv("NOTE_EMAIL", "your-email@example.com")
NOTE_PASSWORD = os.getenv("NOTE_PASSWORD", "your-password")

# OpenAI (ChatGPT) の APIキー設定
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "sk-xxx")

# ====================================
# [ 設定 / 自動生成のお題（プロンプト） ]
# どのような記事を生成させたいかを記述してください。
# ※「1行目にタイトルを、2行目以降に本文を」などの指示は必ず入れてください。
# ====================================
CHATGPT_PROMPT = os.getenv("CHATGPT_PROMPT", """
あなたはプロのブロガーです。毎日のモチベーションが上がる短い名言を一つ紹介し、
その意味と、今日からできる具体的なアクションプランを熱く語るNote記事を作成してください。

※必ず、1行目に記事の「タイトル」だけを単独で出力し、少し改行を挟んでから本文を書き始めてください。
※Markdownなどの装飾記号（# や **）は極力使わず、プレーンテキストとして綺麗に読めるよう調整してください。
""")
# ====================================

# 実行状態を保持
article_data = {
    "title": "",
    "body": ""
}

def generate_article_with_chatgpt():
    if not OPENAI_API_KEY or OPENAI_API_KEY == "sk-xxx":
         print("エラー: OPENAI_API_KEY が設定されていません。")
         print("環境変数、またはソースコード先頭の設定をご確認ください。")
         sys.exit(1)

    print("🤖 ChatGPTに記事を執筆させています...")
    client = OpenAI(api_key=OPENAI_API_KEY)
    
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": CHATGPT_PROMPT}
            ],
            temperature=0.7
        )
    except Exception as e:
        print(f"ChatGPT API通信中にエラーが発生しました: {e}")
        sys.exit(1)
        
    generated_text = response.choices[0].message.content.strip()
    
    # 1行目をタイトル、それ以降を本文として分割
    lines = generated_text.split('\n')
    if len(lines) < 2:
        print("ChatGPTの出力フォーマットエラー: 複数行の出力を期待していましたが、1行しかありません。")
        sys.exit(1)
        
    # 空行を取り除きつつタイトルを抽出
    title = lines[0].strip().lstrip('#').strip()
    
    # 残りの行を結合して本文にする（最初の空行などをスキップ）
    body_lines = lines[1:]
    while body_lines and not body_lines[0].strip():
        body_lines.pop(0)
        
    body = '\n'.join(body_lines)
    
    if not title or not body:
         print("記事の分解に失敗しました。プロンプトの内容を見直してください。")
         sys.exit(1)
         
    article_data["title"] = title
    article_data["body"] = body
    
    print(f"📝 執筆完了！\n【タイトル】{title}\n【文字数】{len(body)}文字")

def login(driver):
    print("ログインページへアクセス中...")
    driver.get("https://note.com/login")
    wait = WebDriverWait(driver, 15)
    
    email_input = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "input[type='email']")))
    pwd_input = driver.find_element(By.CSS_SELECTOR, "input[type='password']")
    
    email_input.clear()
    email_input.send_keys(NOTE_EMAIL)
    pwd_input.clear()
    pwd_input.send_keys(NOTE_PASSWORD)
    
    submit_btn = driver.find_element(By.CSS_SELECTOR, "button[type='submit']")
    submit_btn.click()
    
    time.sleep(5)
    if "login" in driver.current_url or "signin" in driver.current_url:
        print("ログインに失敗しました。NOTE_EMAIL と NOTE_PASSWORD を確認してください。")
        driver.quit()
        sys.exit(1)
    
    print("ログイン成功！")

def create_article(driver):
    print("新規投稿画面を開きます...")
    driver.get("https://editor.note.com/")
    wait = WebDriverWait(driver, 15)
    
    try:
        title_input = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "textarea[placeholder*='タイトル']")))
    except:
        title_input = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "input[placeholder*='タイトル']")))
        
    title_input.clear()
    title_input.send_keys(article_data["title"])
    
    editor = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "[contenteditable='true']")))
    editor.click()
    
    print("本文を入力中...")
    lines = article_data["body"].split("\n")
    for line in lines:
        if not line:
            editor.send_keys(Keys.ENTER)
        else:
            driver.execute_script("arguments[0].dispatchEvent(new KeyboardEvent('keydown', {key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true}));", editor)
            editor.send_keys(line)
            editor.send_keys(Keys.ENTER)
    time.sleep(2)
    print("記事の入力が完了しました。")

def publish(driver):
    print("公開処理を開始します...")
    wait = WebDriverWait(driver, 20)
    
    try:
        publish_btn = wait.until(EC.element_to_be_clickable((By.XPATH, "//button[contains(., '公開設定')]")))
    except:
        try:
             publish_btn = wait.until(EC.element_to_be_clickable((By.XPATH, "//button[contains(., '公開に進む')]")))
        except:
             print("「公開設定」ボタンが見つかりませんでした。手動でご確認ください。")
             return
        
    driver.execute_script("arguments[0].click();", publish_btn)
    time.sleep(3)
    
    try:
        final_publish_btn = wait.until(EC.element_to_be_clickable((By.XPATH, "//button[contains(., '公開する')]")))
        driver.execute_script("arguments[0].click();", final_publish_btn)
    except:
        pass

    time.sleep(5)
    print("自動生成＆自動投稿の全プロセスが完了しました！")

def main():
    if not NOTE_EMAIL or NOTE_EMAIL == "your-email@example.com":
        print("エラー: NOTE_EMAIL が設定されていません。先頭の設定や環境変数をご確認ください。")
        sys.exit(1)

    # 先にChatGPTで記事を生成
    generate_article_with_chatgpt()

    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--window-size=1920,1080")
    
    if os.getenv("GITHUB_ACTIONS") == "true" or os.getenv("HEADLESS") == "1":
        print("サーバー環境(ヘッドレスモード)でブラウザを起動します...")
        options.add_argument("--headless")
    
    print("ドライバを準備中...")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    
    try:
        login(driver)
        create_article(driver)
        publish(driver)
    except Exception as e:
        print(f"自動投稿プロセス中にエラーが発生しました: {e}")
        sys.exit(1)
    finally:
        driver.quit()

if __name__ == "__main__":
    main()
