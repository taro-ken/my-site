# Note自動投稿・完全自動化（ChatGPT生成対応）ガイド

このフォルダには、毎日決まった時間にパソコンを閉じていても、**ChatGPTが自動で新しい記事（あなたのお題に合わせた文章）を考案し、勝手にNoteに投稿してくれる**「完全自動化」に必要なテンプレートが揃っています。
GitHubというオンラインの無料サービスを使って設定します。

## 💡 設定手順（3ステップ）

### Step 1: GitHubへのアップロード
1. [GitHub](https://github.com/) にアクセスし、無料アカウントを作成してログインします。
2. 左上の「New」から新しいリポジトリ（保管庫）を作成し「Private（非公開）」に設定します。
3. 作成した画面で「Upload an existing file」を選び、**このzipの中身すべて**をアップロードして保存します。

### Step 2: 機密情報の安全な設定 (Secrets)
このスクリプトは、あなたのNoteへログインし、ChatGPTに文章を書かせるため、それらへのアクセスキーをGitHubの秘密の金庫である `Secrets` に設定します。

1. GitHubのアップロードした画面上部の「Settings（設定）」タブを開きます。
2. 左メニューの下の方にある「Secrets and variables」の▼を押して「Actions」を選びます。
3. 緑色の【New repository secret】ボタンを押し、以下の **3つ** を別々に登録してください。
   - Name: `NOTE_EMAIL` ／ Secret: `あなたのNoteログイン用メールアドレス`
   - Name: `NOTE_PASSWORD` ／ Secret: `あなたのログイン用パスワード`
   - Name: `OPENAI_API_KEY` ／ Secret: `あなたのOpenAI(ChatGPT)のAPIキー(sk-...から始まるもの)`

### Step 3: どんな記事を書かせるか（プロンプトの変更）
どんなテーマのブログを運営するかは自由自在です。

1. GitHubのファイルリストから `.github/workflows/schedule_post.yml` をクリックし、右側の鉛筆アイコン（Edit）を押します。
2. `CHATGPT_PROMPT:` の下に書かれているプロンプトを、好きな内容に変更してください。
   * 例えば：「ITニュースの解説」「今日の占いとラッキーアイテム」「3分で読める小話」等。
   * **※「必ず1行目に記事のタイトルを出力する」という制約は消さないでください。**
3. 変更したら右上の「Commit changes...」を押して保存します。

**【手動でのテスト＆自動時間の変更】**
- 上部タブの「Actions」から「Note Auto Post Schedule」を選び、「Run workflow」を押すと、クラウド上でChatGPTが文章を作り投稿テストが始まります。
- 毎日投稿する時間を変えたい場合は、`.github/workflows/schedule_post.yml` ファイル内の `cron:` リストで時間を変更できます（UTC時間のため、日本時間から9時間引いた値にしてください）。

これだけで、「寝ている間に新しい記事を生み出し続ける」ブログマシーンの完成です！
