import argparse
import json
import os
from pathlib import Path
from typing import Dict, Any, List
from dotenv import load_dotenv

from openai import OpenAI

load_dotenv()

# ==========================================
# OpenAI API 設定
# ==========================================
API_KEY = os.getenv("OPENAI_API_KEY", "")
MODEL_NAME = os.getenv("OPENAI_MODEL_NAME", "gpt-4o-mini")

if not API_KEY:
    raise ValueError("OPENAI_API_KEY が設定されていません。.envファイルを確認してください。")

client = OpenAI(api_key=API_KEY)

MAX_SCENES = 5
DEFAULT_THEME = "あなたの人生を変える3つの習慣"
DEFAULT_TARGET = "毎日忙しくて自分の時間がない人"

def call_openai_json(prompt: str) -> Dict[str, Any]:
    res = client.chat.completions.create(
        model=MODEL_NAME,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": "You are a helpful assistant that ONLY responds with valid JSON."},
            {"role": "user", "content": prompt},
        ],
    )
    return json.loads(res.choices[0].message.content)

def generate_theme_from_input(theme: str, target: str) -> Dict[str, Any]:
    prompt = f"""
あなたはYouTubeショート向けの企画担当です。
以下のテーマについて、ショート動画1本分の企画情報をJSONで出してください。

テーマ: {theme}
想定視聴者 (ターゲット): {target}

出力形式:
{{
  "videoTitle": "動画タイトル（そのまま表示用）",
  "hook": "ショート動画の冒頭で使える一言のフック（20〜35文字程度）"
}}

条件:
- hook は視聴者の悩みを直接刺す言葉にしてください
"""
    return call_openai_json(prompt.strip())

def generate_story(theme_info: Dict[str, Any], target: str) -> Dict[str, Any]:
    title = theme_info.get("videoTitle", "ショート動画").strip()
    hook = theme_info.get("hook", "").strip()

    prompt = f"""
あなたはYouTubeショートの構成作家です。

今回扱うテーマ: 「{title}」
想定視聴者: 「{target}」
冒頭フック: 「{hook}」

### 動画の方向性
・このテーマをエッセンスとして「3つのポイント」に絞って伝えてください
・「明日からこう変えよう」と思える実践イメージを入れてください
・難しい専門用語は避け、日常の例に置き換えてください

### 構成（5シーン）
- scene0: 冒頭フック＋この動画でわかること
- scene1: 現状の悩み（どんな悩みを解決するか）
- scene2: ポイント1（一番刺さる解決策）
- scene3: ポイント2（別角度の重要ポイント）
- scene4: ポイント3＋まとめ＋視聴者への背中を押す一言

### 字幕テキストの制約
- 1シーン2〜4行、合計40〜90文字程度。
- 「あなたは〜した方がいいです」のように視聴者に語りかける形。

### 画像のプロンプト
各シーンごとに「シネマティックな背景画像」を描画するための imagePrompt を必ず付けてください。
場所、人物（性別・年代）、感情を含めてください。

### 出力形式（重要）
{{
  "title": "動画タイトル（15〜30文字程度）",
  "scenes": [
    {{
      "id": "scene0",
      "text": "・・・",
      "imagePrompt": "・・・",
      "durationSec": 8
    }},
    ... scene1〜scene4 ...
  ]
}}
"""
    return call_openai_json(prompt.strip())

def normalize_story(raw: Dict[str, Any]) -> Dict[str, Any]:
    title = raw.get("title", "ショート動画").strip()
    scenes_raw = raw.get("scenes", [])
    normalized_scenes = []

    for idx, s in enumerate(scenes_raw[:MAX_SCENES]):
        dur = max(7, min(10, int(s.get("durationSec", 8))))
        normalized_scenes.append(
            {
                "id": s.get("id", f"scene{idx}"),
                "text": str(s.get("text", "")).strip(),
                "bgImage": f"scene{idx}.png",
                "durationSec": dur,
                "imagePrompt": str(s.get("imagePrompt", "")).strip(),
            }
        )

    # アウトロ追加（汎用）
    normalized_scenes.append(
        {
            "id": "scene5",
            "text": "役に立つ情報を発信中です。\nぜひチャンネル登録お願いします！",
            "bgImage": "outro.png",
            "durationSec": 6,
            "imagePrompt": ""
        }
    )

    return {"title": title, "scenes": normalized_scenes}

def main():
    parser = argparse.ArgumentParser(description="ショート動画用 story_props.json 生成スクリプト")
    parser.add_argument("--theme", help="テーマ")
    parser.add_argument("--target", help="ターゲット")
    args = parser.parse_args()

    theme = args.theme or DEFAULT_THEME
    target = args.target or DEFAULT_TARGET

    print("🧠 テーマ生成中...")
    theme_info = generate_theme_from_input(theme, target)
    print(f"  → hook: {theme_info.get('hook')}")

    print("📖 ストーリー生成中...")
    raw_story = generate_story(theme_info, target)
    story = normalize_story(raw_story)

    # React(Remotion)に渡すプロパティ
    story_props = {
        "title": story["title"],
        "scenes": story["scenes"],
        "fps": 30
    }

    out_path = Path("src/data/story_props.json")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(story_props, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"✅ 生成完了: {out_path.resolve()}")

if __name__ == "__main__":
    main()
