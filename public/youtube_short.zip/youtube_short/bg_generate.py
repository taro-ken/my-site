# bg_generate.py
import json
import base64
import os
import time
from pathlib import Path
import requests
from openai import OpenAI
from dotenv import load_dotenv

# 環境変数を読み込む
load_dotenv()

# ===== API KEY =====
# 複数のAPIキーをサポート（カンマ区切りで指定可能）
STABILITY_API_KEYS_STR = os.getenv("STABILITY_API_KEYS", os.getenv("STABILITY_API_KEY", ""))
if STABILITY_API_KEYS_STR:
    # カンマ区切りで複数のキーを分割
    STABILITY_API_KEYS = [key.strip() for key in STABILITY_API_KEYS_STR.split(",") if key.strip()]
else:
    STABILITY_API_KEYS = []

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")

if not STABILITY_API_KEYS:
    raise ValueError("STABILITY_API_KEY または STABILITY_API_KEYS が設定されていません。.envファイルを確認してください。")
if not OPENAI_API_KEY:
    raise ValueError("OPENAI_API_KEY が設定されていません。.envファイルを確認してください。")

client = OpenAI(api_key=OPENAI_API_KEY)

# APIキーのローテーション用カウンター
_api_key_index = 0

API_HOST = "https://api.stability.ai"
ENGINE_ID = "stable-diffusion-xl-1024-v1-0"


def translate_to_english(text: str) -> str:
    prompt = f"""
Translate the following Japanese prompt into high-quality English
for text-to-image generation. Return ONLY the English.

{text}
    """.strip()

    res = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[
            {"role": "system", "content": "Translate Japanese to English."},
            {"role": "user", "content": prompt},
        ],
    )
    return res.choices[0].message.content.strip()


def get_next_api_key():
    """次のAPIキーを取得（ローテーション）"""
    global _api_key_index
    if not STABILITY_API_KEYS:
        raise RuntimeError("STABILITY_API_KEYS が設定されていません")
    
    api_key = STABILITY_API_KEYS[_api_key_index % len(STABILITY_API_KEYS)]
    _api_key_index += 1
    return api_key


def generate_image_for_scene(filename: str, prompt_ja: str) -> None:
    if not STABILITY_API_KEYS:
        raise RuntimeError("STABILITY_API_KEYS が設定されていません")

    prompt_en = translate_to_english(prompt_ja)

    print(f"🧪 画像生成: {filename}")
    print(f"   JP: {prompt_ja}")
    print(f"   EN: {prompt_en}")

    url = f"{API_HOST}/v1/generation/{ENGINE_ID}/text-to-image"

    payload = {
        "steps": 30,
        "width": 768,
        "height": 1344,
        "seed": 0,
        "cfg_scale": 7.0,
        "samples": 1,
        "style_preset": "photographic",
        "text_prompts": [{"text": prompt_en, "weight": 1.0}],
    }

    # リトライ処理（レート制限エラー対応）
    # Stability AI API: 10秒あたり150リクエスト、429エラー時は60秒タイムアウト
    max_retries = 3
    retry_delay = 60  # API仕様に合わせて60秒待機
    
    # 最初のAPIキーを取得
    current_api_key = get_next_api_key()
    print(f"   🔑 使用APIキー: {current_api_key[:20]}...")
    
    for attempt in range(max_retries):
        try:
            # 現在のAPIキーでリクエスト
            headers = {
                "Authorization": f"Bearer {current_api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            }
            
            resp = requests.post(url, headers=headers, json=payload, timeout=60)
            
            if resp.status_code == 429:
                # レート制限エラーまたはクレジット不足
                error_detail = ""
                try:
                    error_data = resp.json()
                    error_detail = error_data.get("message", "")
                except:
                    error_detail = resp.text[:200]  # 最初の200文字
                
                # クレジット不足の場合は別のAPIキーに切り替えても意味がないので、すぐにエラーを出す
                is_insufficient_balance = "balance" in error_detail.lower() or "not have enough" in error_detail.lower()
                
                if is_insufficient_balance:
                    print(f"❌ クレジット残高不足 (429): {error_detail}")
                    print(f"   → Stability AIのダッシュボードでクレジットを追加してください")
                    print(f"   → または、十分なクレジットがある別のAPIキーを使用してください")
                    raise RuntimeError(f"Stability AI APIのクレジット残高不足: {error_detail}")
                
                print(f"⚠️ レート制限エラー (429): {error_detail}")
                
                # 別のAPIキーがある場合は切り替え（クレジット不足でない場合のみ）
                if len(STABILITY_API_KEYS) > 1 and attempt < max_retries - 1:
                    print(f"   🔄 別のAPIキーに切り替えます...")
                    current_api_key = get_next_api_key()
                    print(f"   🔑 新しいAPIキー: {current_api_key[:20]}...")
                    # 少し待機してから再試行
                    time.sleep(2)
                    continue
                
                if attempt < max_retries - 1:
                    # Retry-Afterヘッダーがあればそれを使用、なければ60秒
                    retry_after = resp.headers.get("Retry-After")
                    if retry_after:
                        wait_time = int(retry_after)
                        print(f"   Retry-Afterヘッダーに基づき{wait_time}秒待機します...")
                    else:
                        wait_time = retry_delay
                        print(f"   {wait_time}秒待機してリトライします... (試行 {attempt + 1}/{max_retries})")
                    
                    time.sleep(wait_time)
                    continue
                else:
                    print(f"❌ レート制限エラー: 最大リトライ回数に達しました")
                    print(f"   考えられる原因:")
                    print(f"   1. APIキーのクレジットが不足している")
                    print(f"   2. 1日のリクエスト数制限に達している")
                    print(f"   3. APIキーが無効または期限切れ")
                    print(f"   → Stability AIのダッシュボードでAPIキーの状態を確認してください")
                    raise RuntimeError(f"Stability AI APIのレート制限エラー: {error_detail}")
            
            resp.raise_for_status()
            data = resp.json()

            b64 = data["artifacts"][0]["base64"]
            img_bytes = base64.b64decode(b64)

            out_path = Path("public") / filename
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_bytes(img_bytes)

            print(f"✅ 保存: {out_path}")
            return
            
        except requests.exceptions.HTTPError as e:
            if e.response and e.response.status_code == 429:
                error_detail = ""
                try:
                    error_data = e.response.json()
                    error_detail = error_data.get("message", "")
                except:
                    error_detail = e.response.text[:200] if e.response.text else ""
                
                # クレジット不足の場合は別のAPIキーに切り替えても意味がないので、すぐにエラーを出す
                is_insufficient_balance = "balance" in error_detail.lower() or "not have enough" in error_detail.lower()
                
                if is_insufficient_balance:
                    print(f"❌ クレジット残高不足 (429): {error_detail}")
                    print(f"   → Stability AIのダッシュボードでクレジットを追加してください")
                    print(f"   → または、十分なクレジットがある別のAPIキーを使用してください")
                    raise RuntimeError(f"Stability AI APIのクレジット残高不足: {error_detail}")
                
                print(f"⚠️ レート制限エラー (429): {error_detail}")
                
                if attempt < max_retries - 1:
                    retry_after = e.response.headers.get("Retry-After") if e.response else None
                    if retry_after:
                        wait_time = int(retry_after)
                        print(f"   Retry-Afterヘッダーに基づき{wait_time}秒待機します...")
                    else:
                        wait_time = retry_delay
                        print(f"   {wait_time}秒待機してリトライします... (試行 {attempt + 1}/{max_retries})")
                    
                    time.sleep(wait_time)
                    continue
                else:
                    print(f"❌ レート制限エラー: 最大リトライ回数に達しました")
                    print(f"   → Stability AIのダッシュボードでAPIキーの状態を確認してください")
                    raise
            else:
                # その他のHTTPエラー
                print(f"❌ HTTPエラー: {e}")
                if e.response:
                    print(f"   ステータスコード: {e.response.status_code}")
                    print(f"   レスポンス: {e.response.text[:200]}")
                raise


def generate_bg_images_from_story():
    story_path = Path("src/data/story_props.json")
    if not story_path.exists():
        raise FileNotFoundError("src/data/story_props.json がありません")

    story = json.loads(story_path.read_text(encoding="utf-8"))
    scenes = story.get("scenes", [])

    # Stability AI API: 10秒あたり150リクエスト制限
    # 安全のため、各画像生成の間に0.1秒待機（10秒/100リクエスト以下に制御）
    request_interval = 0.1  # 秒
    
    for idx, scene in enumerate(scenes):
        # scene5（アウトロ）は画像生成しない
        if scene["id"] == "scene5":
            print("⏭  scene5/outro は固定画像のため生成スキップ")
            continue
        filename = scene["bgImage"]
        prompt = scene.get("imagePrompt") or scene.get("text")
        out_path = Path("public") / filename
        if out_path.exists():
            print(f"🔄 既に存在: {filename} → 上書きします")
        
        generate_image_for_scene(filename, prompt)
        
        # 最後の画像でない場合、次のリクエストまで待機（レート制限対策）
        if idx < len(scenes) - 1:
            time.sleep(request_interval)


if __name__ == "__main__":
    generate_bg_images_from_story()
