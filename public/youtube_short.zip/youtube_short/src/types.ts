export type StoryScene = {
  id: string;
  text: string;
  bgImage: string;
  durationSec: number;
};

export type StoryVideoProps = {
  title: string;
  bookImageUrl?: string;
  scenes: StoryScene[];
};
