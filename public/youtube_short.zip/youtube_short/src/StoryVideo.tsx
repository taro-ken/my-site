import React, { useMemo } from 'react';
import {
	AbsoluteFill,
	Img,
	interpolate,
	useCurrentFrame,
	useVideoConfig,
	staticFile,
	Audio,
	Sequence,
	getInputProps,
} from 'remotion';
import type { StoryVideoProps, StoryScene } from './types';

export const StoryVideo: React.FC<StoryVideoProps> = (props) => {
	const frame = useCurrentFrame();
	const { fps } = useVideoConfig();

	// GitHub Actionsでのみ発生する問題を調査: defaultPropsが正しく渡されているか確認
	const inputProps = getInputProps() as StoryVideoProps;
	const title = props.title || inputProps.title || '本要約ショート';
	const bookImageUrl = props.bookImageUrl || inputProps.bookImageUrl;
	const scenes = props.scenes || inputProps.scenes || [];

	// デバッグ: propsとinputPropsの内容を確認（GitHub Actionsでのみ発生する問題を調査）
	// フレーム0でのみ出力してパフォーマンスへの影響を最小化
	if (frame === 0) {
		console.error('🎬 StoryVideo - Props check (frame 0):', {
			propsKeys: Object.keys(props),
			propsHasScenes: 'scenes' in props,
			propsScenesLength: (props as any).scenes?.length || 'undefined',
			propsScenesType: typeof (props as any).scenes,
			propsScenesIsArray: Array.isArray((props as any).scenes),
			inputPropsKeys: Object.keys(inputProps),
			inputPropsHasScenes: 'scenes' in inputProps,
			inputPropsScenesLength: inputProps.scenes?.length || 'undefined',
			inputPropsScenesType: typeof inputProps.scenes,
			inputPropsScenesIsArray: Array.isArray(inputProps.scenes),
			finalScenesLength: scenes.length,
			finalScenesIsArray: Array.isArray(scenes),
			finalScenesType: typeof scenes,
		});
	}

	// デバッグモード: 通常の実行時は表示しない
	const isDebugMode = false;

	// デバッグ: フレーム0でのみ初期状態を確認
	if (frame === 0) {
		console.error('🎬 StoryVideo - Initial state (frame 0):', {
			title: title || 'undefined',
			bookImageUrl: bookImageUrl || 'undefined',
			scenesLength: scenes?.length || 'undefined',
			scenesIsArray: Array.isArray(scenes),
			scenesType: typeof scenes,
			firstSceneText: scenes?.[0]?.text?.substring(0, 50) || 'No text',
		});
	}
	if (!scenes || scenes.length === 0) {
		console.error('⚠️ StoryVideo: scenes array is empty or undefined!', { 
			title, 
			bookImageUrl, 
			scenes,
			scenesType: typeof scenes,
			scenesIsArray: Array.isArray(scenes),
		});
		// scenesが空の場合は常にエラー画面を表示（GitHub Actionsで問題を特定するため）
		return (
			<AbsoluteFill style={{ backgroundColor: 'red', color: 'white', justifyContent: 'center', alignItems: 'center', fontSize: 48 }}>
				<p>⚠️ ERROR: scenes array is empty or undefined!</p>
				<p>scenes: {scenes ? `Array(${scenes.length})` : 'undefined'}</p>
				<p>title: {title || 'undefined'}</p>
				<p>bookImageUrl: {bookImageUrl || 'undefined'}</p>
			</AbsoluteFill>
		);
	}

	const timedScenes = useMemo(() => {
		let currentStart = Math.round(fps * 3);
		const result = scenes.map((scene) => {
			const sceneDurationFrames = Math.round(scene.durationSec * fps);
			const startFrame = currentStart;
			const endFrame = currentStart + sceneDurationFrames;
			currentStart = endFrame;
			return { ...scene, startFrame, endFrame };
		});
		
		// デバッグ: timedScenesを確認（レンダリング時にも出力されるように条件を緩和）
		if (frame === 0) {
			console.log('📊 StoryVideo - timedScenes (calculated at frame 0):', {
				totalScenes: result.length,
				fps: fps,
				titleStartFrame: Math.round(fps * 3),
				scenes: result.map(s => ({
					id: s.id,
					startFrame: s.startFrame,
					endFrame: s.endFrame,
					durationFrames: s.endFrame - s.startFrame,
					durationSec: s.durationSec,
					textLength: s.text?.length || 0,
					textPreview: s.text?.substring(0, 50) || 'NO TEXT',
				})),
			});
		}
		
		return result;
	}, [scenes, fps]);

	const currentScene = useMemo(() => {
		const found = timedScenes.find((s) => frame >= s.startFrame && frame < s.endFrame);
		// デバッグ: 検索結果を確認（フレーム90-120の範囲で詳細な検索情報を出力）
		if (frame >= 90 && frame <= 120 && frame % 10 === 0) {
			const calculatedOpacity = found ? interpolate(
				frame,
				[found.startFrame, found.startFrame + fps, found.endFrame - fps, found.endFrame],
				[0, 1, 1, 0],
				{ extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }
			) : undefined;
			
			console.error(`🔍 Frame ${frame} (${(frame / fps).toFixed(2)}s) scene search:`, JSON.stringify({
				found: found ? {
					id: found.id,
					startFrame: found.startFrame,
					endFrame: found.endFrame,
					textLength: found.text?.length || 0,
					textPreview: found.text?.substring(0, 100) || 'NO TEXT',
					calculatedOpacity: calculatedOpacity !== undefined ? calculatedOpacity.toFixed(3) : 'N/A',
				} : 'null',
				allScenesChecked: timedScenes.map(s => ({
					id: s.id,
					range: `${s.startFrame}-${s.endFrame}`,
					inRange: frame >= s.startFrame && frame < s.endFrame,
				})),
			}, null, 2));
		}
		return found;
	}, [timedScenes, frame, fps]);

	const showTitle = frame < fps * 3;
	// フェードインなし、静止画として表示
	const titleOpacity = 1;

	const textOpacity = currentScene
		? interpolate(
				frame,
				[
					currentScene.startFrame,
					currentScene.startFrame + fps,
					currentScene.endFrame - fps,
					currentScene.endFrame,
				],
				[0, 1, 1, 0],
				{ extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }
			)
		: undefined;

	// デバッグ: currentSceneとtextOpacityを確認（フレーム90-120の範囲で詳細な情報を出力）
	// 次のログ確認で原因を特定するため、すべての重要な情報を出力
	// GitHub Actionsでのみ発生する問題を調査するため、より広い範囲でログを出力
	if ((frame >= 90 && frame <= 120 && frame % 10 === 0) || (frame >= 90 && frame <= 120 && frame % 1 === 0 && frame <= 100)) {
		const calculatedOpacity = currentScene ? interpolate(
			frame,
			[
				currentScene.startFrame,
				currentScene.startFrame + fps,
				currentScene.endFrame - fps,
				currentScene.endFrame,
			],
			[0, 1, 1, 0],
			{ extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }
		) : undefined;
		
		console.error(`📊 StoryVideo - frame ${frame} (${(frame / fps).toFixed(2)}s) - FULL DEBUG:`, JSON.stringify({
			scenesLength: scenes.length,
			timedScenesLength: timedScenes.length,
			currentScene: currentScene ? {
				id: currentScene.id,
				startFrame: currentScene.startFrame,
				endFrame: currentScene.endFrame,
				textLength: currentScene.text?.length || 0,
				textExists: !!currentScene.text,
				textFull: currentScene.text || 'NO TEXT',
			} : 'null',
			textOpacity: textOpacity,
			calculatedOpacity: calculatedOpacity,
			textOpacityNumber: typeof textOpacity === 'number' ? textOpacity : 'NOT A NUMBER',
			textOpacityGreaterThanZero: textOpacity !== undefined && textOpacity > 0,
			showTitle: showTitle,
			willRenderText: currentScene && currentScene.text && textOpacity !== undefined && textOpacity > 0,
			renderCondition: {
				currentSceneExists: !!currentScene,
				currentSceneTextExists: !!currentScene?.text,
				textOpacityIsNumber: typeof textOpacity === 'number',
				textOpacityGreaterThanZero: textOpacity !== undefined && textOpacity > 0,
				allConditionsMet: !!(currentScene && currentScene.text && textOpacity !== undefined && textOpacity > 0),
			},
		}, null, 2));
	}

	// デバッグ: 通常の実行時は表示しない（isDebugModeは20行目で定義済み）
	// GitHub Actionsでテロップが表示されない問題を調査するため、フレーム90-120の範囲でも表示
	// テロップより下に表示するため、zIndexを低く設定
	const showDebug = isDebugMode && (frame < fps * 5 || (frame >= 90 && frame <= 120) || (!currentScene && !showTitle));
	const debugInfo = showDebug ? (
		<AbsoluteFill style={{ 
			backgroundColor: 'rgba(0,0,0,0.8)', 
			color: 'white', 
			justifyContent: 'flex-start', 
			alignItems: 'flex-start',
			padding: 20,
			fontSize: 20,
			zIndex: 1000,
			pointerEvents: 'none'
		}}>
			<p>DEBUG: scenes.length = {scenes.length}</p>
			<p>DEBUG: timedScenes.length = {timedScenes.length}</p>
			<p>DEBUG: currentScene = {currentScene ? currentScene.id : 'null'}</p>
			<p>DEBUG: frame = {frame}</p>
			<p>DEBUG: showTitle = {showTitle ? 'true' : 'false'}</p>
			<p>DEBUG: textOpacity = {textOpacity !== undefined ? textOpacity.toFixed(2) : 'undefined'}</p>
			{currentScene && (
				<>
					<p>DEBUG: currentScene.text length = {currentScene.text?.length || 0}</p>
					<p>DEBUG: currentScene.text preview = {currentScene.text?.substring(0, 30) || 'NO TEXT'}</p>
				</>
			)}
			{timedScenes.length > 0 && (
				<>
					<p>DEBUG: scene0 range = {timedScenes[0].startFrame}-{timedScenes[0].endFrame}</p>
					<p>DEBUG: frame in range? {frame >= timedScenes[0].startFrame && frame < timedScenes[0].endFrame ? 'YES' : 'NO'}</p>
				</>
			)}
		</AbsoluteFill>
	) : null;

	return (
		<AbsoluteFill style={{ backgroundColor: 'black' }}>
			{debugInfo}
			{/* ▼ ここが追加した BGM */}
			<Audio
				src={staticFile('Martini_Swing.mp3')}
				volume={0.15}   // 声を邪魔しないくらい
				loop            // 動画が終わるまでループ
			/>

			{timedScenes.map((scene) => (
				<Sequence key={scene.id} from={scene.startFrame}>
					<Audio src={staticFile(`${scene.id}.mp3`)} />
				</Sequence>
			))}

			{showTitle && (
				<AbsoluteFill
					style={{
						justifyContent: 'center',
						alignItems: 'center',
						padding: 80,
						opacity: titleOpacity,
						flexDirection: 'column',
						gap: 40,
					}}
				>
					{bookImageUrl && (
						<Img
							src={bookImageUrl}
							style={{
								width: 400,
								height: 600,
								objectFit: 'contain',
								borderRadius: 16,
								boxShadow: '0 8px 32px rgba(0,0,0,0.5)',
							}}
						/>
					)}
					<h1 style={{ color: 'white', fontSize: 64, textAlign: 'center' }}>
						{title}
					</h1>
				</AbsoluteFill>
			)}

			{currentScene ? (
				<AbsoluteFill>
					<AbsoluteFill 
						style={{ 
							overflow: 'hidden', 
							backgroundColor: '#1a1a1a',
							background: currentScene.bgImage === 'outro.png' 
								? 'linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%)'
								: 'linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%)'
						}}
					>
						{currentScene.bgImage && (
							<Img
								src={staticFile(currentScene.bgImage)}
								style={{
									width: '110%',
									height: '110%',
									objectFit: 'cover',
									filter: 'brightness(0.6)',
								}}
							/>
						)}
					</AbsoluteFill>

					<AbsoluteFill
						style={{
							justifyContent: 'center',
							alignItems: 'center',
							padding: 60,
						}}
					>
						{/* テロップを表示（currentSceneが存在する場合は常に表示） */}
						<AbsoluteFill
							style={{
								justifyContent: 'center',
								alignItems: 'center',
								zIndex: 20001,
								pointerEvents: 'none',
							}}
						>
							{(() => {
								const appliedOpacity = typeof textOpacity === 'number' ? textOpacity : 1;
								return (
									<div
										style={{
											width: '100%',
											maxWidth: 900,
											backgroundColor: 'rgba(0,0,0,0.55)',
											borderRadius: 24,
											padding: 32,
											opacity: appliedOpacity,
											fontFamily: '"Noto Sans JP", "Noto Sans CJK JP", "Noto Sans", sans-serif',
										}}
									>
										<p
											style={{
												color: 'white',
												fontSize: 40,
												fontFamily: '"Noto Sans JP", "Noto Sans CJK JP", "Noto Sans", sans-serif',
												whiteSpace: 'pre-wrap',
												margin: 0,
											}}
										>
											{currentScene.text || '⚠️ No text'}
										</p>
									</div>
								);
							})()}
						</AbsoluteFill>
						{/* デバッグ: currentSceneが見つかった場合の情報（デバッグモード時のみ、テロップの下に表示） */}
						{isDebugMode && (frame >= 90 && frame <= 120) && (
							<AbsoluteFill style={{ 
								backgroundColor: 'rgba(255,255,0,0.3)', 
								color: 'white', 
								justifyContent: 'flex-start', 
								alignItems: 'flex-start',
								padding: 20,
								fontSize: 20,
								zIndex: 20000,
								pointerEvents: 'none'
							}}>
								<p>DEBUG: currentScene found!</p>
								<p>ID: {currentScene?.id || 'null'}</p>
								<p>Text length: {currentScene?.text?.length || 0}</p>
								<p>Text preview: {currentScene?.text?.substring(0, 30) || 'NO TEXT'}</p>
								<p>textOpacity: {textOpacity ?? 'undefined'}</p>
								<p>Frame: {frame}</p>
							</AbsoluteFill>
						)}
					</AbsoluteFill>
				</AbsoluteFill>
			) : !showTitle && isDebugMode && (
				// currentSceneが見つからない場合のデバッグ表示（デバッグモード時のみ）
				<AbsoluteFill style={{ backgroundColor: 'yellow', color: 'black', justifyContent: 'center', alignItems: 'center', fontSize: 32 }}>
					<p>⚠️ DEBUG: currentScene is null</p>
					<p>Frame: {frame}</p>
					<p>Scenes count: {scenes.length}</p>
					<p>TimedScenes: {timedScenes.map(s => `${s.id}(${s.startFrame}-${s.endFrame})`).join(', ')}</p>
				</AbsoluteFill>
			)}
		</AbsoluteFill>
	);
};
