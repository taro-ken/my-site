import {Composition} from 'remotion';
import {StoryVideo} from './StoryVideo';
import type {StoryScene} from './types';
// ローカル開発時は静的インポート、GitHub Actionsでは実行時に読み込む
import storyDataStatic from './data/story_props.json';

export const RemotionRoot: React.FC = () => {
	// ローカル開発時は静的インポートを使用
	// GitHub Actionsでは、story_props.jsonをpublic/にコピーして実行時に読み込む
	const fps = (storyDataStatic as any).fps ?? 30;
	const title: string = (storyDataStatic as any).title ?? '本要約ショート';
	const bookImageUrl: string | undefined = (storyDataStatic as any).bookImageUrl;
	const scenes: StoryScene[] = (storyDataStatic as any).scenes ?? [];

	// デバッグ: 読み込まれたデータを確認（レンダリング時にも出力されるように条件を緩和）
	console.log('📊 RemotionRoot - storyData:', {
		title,
		scenesCount: scenes.length,
		firstSceneText: scenes[0]?.text?.substring(0, 50) || 'No text',
		allScenes: scenes.map(s => ({
			id: s.id,
			textLength: s.text?.length || 0,
			durationSec: s.durationSec,
		})),
	});

	if (scenes.length === 0) {
		console.error('⚠️ WARNING: scenes array is empty!', storyDataStatic);
	}

	const totalSeconds =
		3 + scenes.reduce((sum, s) => sum + (s.durationSec ?? 8), 0);
	const durationInFrames = Math.round(totalSeconds * fps);

	// GitHub Actionsでの問題を回避: defaultPropsを明示的にシリアライズ可能な形式で作成
	// Remotionのバンドル時に配列が正しくシリアライズされるように、JSON文字列化してから再度パース
	const defaultPropsValue = {
		title,
		bookImageUrl,
		scenes: JSON.parse(JSON.stringify(scenes)) as StoryScene[], // 明示的なシリアライズ
	};

	// デバッグ: defaultPropsの内容を確認
	console.log('📊 RemotionRoot - defaultProps:', {
		title: defaultPropsValue.title,
		bookImageUrl: defaultPropsValue.bookImageUrl,
		scenesCount: defaultPropsValue.scenes.length,
		scenesIsArray: Array.isArray(defaultPropsValue.scenes),
		firstSceneId: defaultPropsValue.scenes[0]?.id || 'undefined',
		firstSceneText: defaultPropsValue.scenes[0]?.text?.substring(0, 50) || 'undefined',
		allScenes: defaultPropsValue.scenes.map(s => ({
			id: s.id,
			textLength: s.text?.length || 0,
		})),
		// GitHub Actionsでの問題を特定するため、シリアライズ後の型も確認
		scenesStringified: JSON.stringify(defaultPropsValue.scenes).substring(0, 200),
	});

	// デバッグ: Composition作成前の確認
	console.log('📊 RemotionRoot - Creating Composition:', {
		componentName: 'StoryVideo',
		componentType: typeof StoryVideo,
		durationInFrames,
		fps,
		defaultPropsKeys: Object.keys(defaultPropsValue),
	});

	const composition = (
		<Composition
			id="BookSummaryVideo"
			component={StoryVideo}
			durationInFrames={durationInFrames}
			fps={fps}
			width={1080}
			height={1920}
			defaultProps={defaultPropsValue}
		/>
	);

	// デバッグ: Composition作成後の確認
	console.log('📊 RemotionRoot - Composition created successfully');

	return (
		<>
			{composition}
		</>
	);
};
// Force rebundle: 1765179916
// Force rebundle: 1765180651
