import os
import subprocess
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# =========================================================
# 【 📝 お題（プロンプト）設定エリア 】
# どのようなショート動画を作りたいか、ここに書き込んでください！
# （環境変数が設定されている場合はそちらが優先されます）
# =========================================================
VIDEO_THEME = os.getenv("VIDEO_THEME", "睡眠の質を劇的に上げる3つの習慣")
VIDEO_TARGET = os.getenv("VIDEO_TARGET", "毎日疲れが取れなくて悩んでいる社会人")
# =========================================================

PROJECT_DIR = Path(__file__).resolve().parent

# 必要に応じて "python3" や "venv/bin/python" に変更してください
VENV_PYTHON = "python"

def run_code(cmd, name: str):
    print(f"\n==== {name} 実行開始 ====")
    try:
        subprocess.run(
            cmd,
            cwd=PROJECT_DIR,
            check=True,
        )
        print(f"==== {name} 正常終了 ====\n")
    except subprocess.CalledProcessError as e:
        print(f"❌ {name} 実行中にエラーが発生しました")
        raise

def clear_cache():
    # 前回生成されたシーン固有のファイルのみを削除
    subprocess.run("rm -f public/scene*.png public/scene*.mp3 src/data/story_props.json", shell=True, cwd=PROJECT_DIR)

def run_all_tasks(theme: str, target: str):
    print("=== ★ ショート動画 自動生成フロー開始 ★ ===")
    print(f"📌 お題(テーマ): {theme}")
    print(f"🎯 ターゲット層: {target}\n")

    clear_cache()

    # 1. GPTによるストーリー（台本）生成
    run_code([VENV_PYTHON, "story_pipeline.py", "--theme", theme, "--target", target], "台本生成 (story_pipeline.py)")

    # 2. 背景画像生成 (Stability APIなど)
    run_code([VENV_PYTHON, "bg_generate.py"], "画像生成 (bg_generate.py)")

    # 3. 音声生成 (OpenAI TTS)
    run_code([VENV_PYTHON, "tts_generate.py"], "音声生成 (tts_generate.py)")

    # 4. Remotionによる動画レンダリング (out/ディレクトリに書き出し)
    run_code(["npx", "remotion", "render", "LoveStoryVideo", "out/short-video.mp4", "--overwrite"], "動画出力 (remotion render)")
    
    print("=== ★ 生成完了！ out/short-video.mp4 を確認してください ★ ===")

if __name__ == "__main__":
    if not os.getenv("OPENAI_API_KEY"):
        print("【エラー】OPENAI_API_KEY が設定されていません！.envファイルを作成するか環境変数に設定してください。")
        exit(1)
        
    run_all_tasks(VIDEO_THEME, VIDEO_TARGET)