import {Config} from '@remotion/cli/config';

Config.setVideoImageFormat('jpeg');
Config.setCodec('h264');
Config.setConcurrency(4);
Config.setOverwriteOutput(true);

