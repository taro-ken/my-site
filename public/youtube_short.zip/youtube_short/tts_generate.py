# tts_generate.py
import json
import math
import subprocess
from pathlib import Path

from openai import OpenAI
import os
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("OPENAI_API_KEY", "")
TTS_MODEL = "gpt-4o-mini-tts"
VOICE = "onyx"

client = OpenAI(api_key=API_KEY)

STORY_PATH = Path("src/data/story_props.json")
PUBLIC_DIR = Path("public")
PUBLIC_DIR.mkdir(exist_ok=True)


def get_audio_duration_sec(path: Path) -> float:
    result = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_entries",
            "format=duration",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            str(path),
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=True,
    )
    return float(result.stdout.strip())


def generate_tts(text: str, out_path: Path) -> None:
    print(f"🗣 TTS 生成: {out_path.name}")
    resp = client.audio.speech.create(
        model=TTS_MODEL,
        voice=VOICE,
        input=text,
    )
    resp.stream_to_file(out_path)


def main() -> None:
    if not STORY_PATH.exists():
        raise FileNotFoundError("src/data/story_props.json がありません")

    story = json.loads(STORY_PATH.read_text(encoding="utf-8"))
    scenes = story.get("scenes", [])
    if not scenes:
        raise RuntimeError("story_props.json に scenes がありません")

    print("🎧 TTS生成＋durationSec調整 開始...")

    for idx, scene in enumerate(scenes):
        scene_id = scene.get("id", f"scene{idx}")
        text = scene.get("text", "").strip()
        if not text:
            print(f"⚠️ {scene_id}: text が空なのでスキップ")
            continue

        mp3_name = f"{scene_id}.mp3"
        out_path = PUBLIC_DIR / mp3_name

        generate_tts(text, out_path)

        try:
            dur_sec = get_audio_duration_sec(out_path)
        except Exception as e:
            print(f"❌ {scene_id}: 音声長取得に失敗: {e}")
            continue

        new_duration = math.ceil(dur_sec + 0.5)
        print(f"   → {scene_id}: {dur_sec:.2f}秒 → durationSec={new_duration}")
        scene["durationSec"] = new_duration

    STORY_PATH.write_text(
        json.dumps(story, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print("🎉 TTS生成＋durationSec調整 完了")


if __name__ == "__main__":
    main()
