# upload_all_sns.py
"""
Upload-Post APIを使用して複数のSNSプラットフォームに動画をアップロード
対応プラットフォーム: TikTok, Instagram, LinkedIn, YouTube, Facebook, Twitter, Threads, Pinterest, Bluesky
"""
import os
import sys
import json
import argparse
import requests
import time
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv

# Google Sheets API用（サービスアカウントのみ）
from google.oauth2 import service_account
from googleapiclient.discovery import build

# 環境変数を読み込む
load_dotenv()

STORY_JSON_PATH = "src/data/story_props.json"

# Upload-Post API設定
# .envファイルから読み込み
UPLOAD_POST_API_KEY = os.getenv("UPLOAD_POST_API_KEY", "")
UPLOAD_POST_USER = os.getenv("UPLOAD_POST_USER", "your_profile_name")
UPLOAD_POST_API_URL = "https://api.upload-post.com/api/upload"

# Google Sheets設定
# .envファイルから読み込み
SPREADSHEET_ID = os.getenv("SPREADSHEET_ID", "")
SHEET_NAME = os.getenv("SHEET_NAME", "Sheet1")
GOOGLE_SERVICE_ACCOUNT_FILE = "google_service_account.json"  # サービスアカウント用（必須）

# 注意: サービスアカウントの設定が必要です:
# 1. Google Cloud Consoleでサービスアカウントを作成
# 2. サービスアカウントキー（JSON）をダウンロードしてgoogle_service_account.jsonとして保存
# 3. スプレッドシートにサービスアカウントのメールアドレスを「編集者」として共有
# 詳細: GOOGLE_SERVICE_ACCOUNT_SETUP.md を参照


def load_story_from_json(json_path: str):
    """story_props.jsonから情報を読み込む"""
    if not os.path.exists(json_path):
        print(f"ERROR: {json_path} が見つかりません")
        sys.exit(1)

    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    return {
        "title": data.get("title", "ショート動画"),
    }


def build_description(meta: dict) -> str:
    title = meta.get("title", "ショート動画")
    hashtags = build_hashtags(meta)

    lines = [
        f"『{title}』",
        hashtags,
        "",
        "フォロー・いいねいただけると励みになります🙏"
    ]
    return "\n".join(lines)


def build_youtube_description(meta: dict) -> str:
    """YouTube用の説明文を生成（タイトルは含まない、ハッシュタグは基本ハッシュタグのみ）"""
    amazon = meta.get("amazon_link") or ""
    rakuten = meta.get("rakuten_link") or ""
    hashtags = build_hashtags(meta)  # 基本ハッシュタグのみ

    lines = []

    # ハッシュタグのみ（タイトルは含まない）
    lines.append(hashtags)
    lines.append("")

    if amazon or rakuten:
        lines.append("【今回紹介した本はこちら】")
        if amazon:
            lines.append(f"Amazon: {amazon}")
        if rakuten:
            lines.append(f"楽天: {rakuten}")
        lines.append("")

    lines.append("フォロー・いいねいただけると励みになります🙏")

    return "\n".join(lines)


def build_x_description(meta: dict) -> str:
    """X (Twitter)用の説明文を生成（タイトルは含まない、ハッシュタグは最後）"""
    amazon = meta.get("amazon_link") or ""
    rakuten = meta.get("rakuten_link") or ""
    hashtags = build_hashtags(meta)  # 基本ハッシュタグのみ

    lines = []

    # 【今回紹介した本はこちら】から始まる
    if amazon or rakuten:
        lines.append("【今回紹介した本はこちら】")
        if amazon:
            lines.append(f"Amazon: {amazon}")
        if rakuten:
            lines.append(f"楽天: {rakuten}")
        lines.append("")

    lines.append("フォロー・いいねいただけると励みになります🙏")
    lines.append("")
    lines.append(hashtags)

    return "\n".join(lines)


def build_hashtags(meta: dict) -> str:
    hashtags = ["#ショート動画", "#ライフハック", "#ビジネス", "#自己啓発", "#豆知識"]
    return " ".join(hashtags)


def build_title_with_hashtags(meta: dict) -> str:
    title = meta.get("title", "ショート動画")
    hashtags = build_hashtags(meta)
    return f"『{title}』 {hashtags}"


def build_youtube_title(meta: dict, limit: int = 100) -> str:
    """
    YouTube用タイトルを生成（ハッシュタグなし、必要なら100文字にトリム）
    """
    base = ""
    book_title = meta.get("book_title") or ""
    if book_title:
        base = f"『{book_title}』"
    else:
        base = meta.get("title", "本要約ショート")

    if len(base) <= limit:
        return base

    # 末尾を「…」でトリム
    if limit <= 1:
        return base[:limit]
    return base[: limit - 1] + "…"


def build_tiktok_title(meta: dict) -> str:
    """TikTok用のタイトルを生成（build_title_with_hashtagsを使用）"""
    return build_title_with_hashtags(meta)


def get_google_sheets_service():
    """Google Sheets APIの認証済みサービスを取得（サービスアカウントのみ）"""
    SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]
    
    if not os.path.exists(GOOGLE_SERVICE_ACCOUNT_FILE):
        print(f"❌ {GOOGLE_SERVICE_ACCOUNT_FILE} が見つかりません")
        print("   サービスアカウントの設定が必要です。")
        print("   詳細: GOOGLE_SERVICE_ACCOUNT_SETUP.md を参照してください")
        return None
    
    try:
        print("🔐 サービスアカウントを使用して認証中...")
        creds = service_account.Credentials.from_service_account_file(
            GOOGLE_SERVICE_ACCOUNT_FILE, scopes=SCOPES
        )
        service = build("sheets", "v4", credentials=creds)
        print("✅ サービスアカウント認証成功（期限切れなし）")
        return service
    except Exception as e:
        print(f"❌ サービスアカウント認証に失敗: {e}")
        print("   サービスアカウントキーが正しいか、スプレッドシートに共有されているか確認してください")
        return None


def get_sheet_names(service, spreadsheet_id: str):
    """スプレッドシート内のシート名一覧を取得"""
    try:
        spreadsheet = service.spreadsheets().get(spreadsheetId=spreadsheet_id).execute()
        return [sheet['properties']['title'] for sheet in spreadsheet.get('sheets', [])]
    except Exception as e:
        print(f"⚠️ シート名取得エラー: {e}")
        return []


def ensure_header_row(service, spreadsheet_id: str, sheet_name: str):
    """ヘッダー行が存在するか確認し、なければ作成する"""
    try:
        # まず、実際のシート名を確認
        sheet_names = get_sheet_names(service, spreadsheet_id)
        if not sheet_names:
            print("❌ シートが見つかりません")
            return False, sheet_name
        
        # 指定されたシート名が存在するか確認
        if sheet_name not in sheet_names:
            print(f"⚠️ シート名 '{sheet_name}' が見つかりません")
            print(f"   利用可能なシート: {', '.join(sheet_names)}")
            # 最初のシートを使用
            actual_sheet_name = sheet_names[0]
            print(f"   → 最初のシート '{actual_sheet_name}' を使用します")
            sheet_name = actual_sheet_name
        
        # シート名に特殊文字が含まれている場合に備えてクォート
        range_name = f"'{sheet_name}'!A1:Z1"
        result = service.spreadsheets().values().get(
            spreadsheetId=spreadsheet_id,
            range=range_name
        ).execute()
        
        values = result.get("values", [])
        
        # ヘッダー行が存在しない、または空の場合は作成
        if not values or not values[0] or values[0][0] != "日時":
            header_row = [
                "日時",
                "タイトル",
                "TikTok URL",
                "Instagram URL",
                "YouTube URL",
                "Facebook URL",
                "Twitter URL",
                "LinkedIn URL",
                "Threads URL",
                "Pinterest URL",
                "Bluesky URL",
            ]
            
            body = {
                "values": [header_row]
            }
            
            # ヘッダー行を書き込み（既存データがある場合は上書きしない）
            range_for_update = f"'{sheet_name}'!A1"
            if not values:
                service.spreadsheets().values().update(
                    spreadsheetId=spreadsheet_id,
                    range=range_for_update,
                    valueInputOption="USER_ENTERED",
                    body=body
                ).execute()
                print("📊 ヘッダー行を作成しました")
            else:
                # 既存データがある場合は、ヘッダー行を挿入
                service.spreadsheets().values().update(
                    spreadsheetId=spreadsheet_id,
                    range=range_for_update,
                    valueInputOption="USER_ENTERED",
                    body=body
                ).execute()
                print("📊 ヘッダー行を更新しました")
        
        return True, sheet_name
    except Exception as e:
        print(f"⚠️ ヘッダー行の確認/作成エラー: {e}")
        return False, sheet_name


def write_to_spreadsheet(title: str, results: dict, spreadsheet_id: str, sheet_name: str, max_retries: int = 3):
    """
    スプレッドシートにタイトルと動画URLを書き込む（リトライ機能付き）
    
    Args:
        title: 書籍名（bookTitleを優先）
        results: アップロード結果（platform -> {success, url, error}）
        spreadsheet_id: スプレッドシートID
        sheet_name: シート名
        max_retries: 最大リトライ回数（デフォルト: 3）
    """
    print(f"📊 スプレッドシート書き込み開始...")
    print(f"   Spreadsheet ID: {spreadsheet_id[:20]}..." if spreadsheet_id else "   Spreadsheet ID: 未設定")
    print(f"   Sheet名: {sheet_name}")
    
    if not spreadsheet_id:
        print("⚠️ スプレッドシートIDが設定されていません。スキップします。")
        print("   .envファイルに SPREADSHEET_ID を設定してください")
        return False

    # リトライ処理
    for attempt in range(max_retries):
        try:
            if attempt > 0:
                wait_time = 2 ** attempt  # 指数バックオフ: 2秒、4秒、8秒
                print(f"   ⏳ {wait_time}秒待機してリトライします... (試行 {attempt + 1}/{max_retries})")
                time.sleep(wait_time)
            
            print("   Google Sheets API認証中...")
            service = get_google_sheets_service()
            if not service:
                print("⚠️ Google Sheets API認証に失敗しました")
                if attempt < max_retries - 1:
                    continue
                return False

            print("   ヘッダー行を確認中...")
            # ヘッダー行を確認・作成
            success, actual_sheet_name = ensure_header_row(service, spreadsheet_id, sheet_name)
            if not success:
                print("⚠️ ヘッダー行の確認/作成に失敗しました")
                if attempt < max_retries - 1:
                    continue
                return False
            # 実際のシート名を使用
            sheet_name = actual_sheet_name

            # 現在の日時（日本語形式: 2025年10月12日）
            now = datetime.now().strftime("%Y年%m月%d日")
            
            # データを準備
            # 形式: [日時, タイトル, TikTok URL, Instagram URL, YouTube URL, ...]
            row_data = [now, title]
            
            # プラットフォームごとのURLを追加（ヘッダーと同じ順序）
            platform_order = ["tiktok", "instagram", "youtube", "facebook", "twitter", "linkedin", "threads", "pinterest", "bluesky"]
            for platform in platform_order:
                if platform in results:
                    platform_result = results[platform]
                    if platform_result.get("success"):
                        # URLは post_url キーを使用
                        url = platform_result.get("post_url") or platform_result.get("url", "")
                        row_data.append(url)
                    else:
                        # エラーメッセージは error_message キーを使用
                        error = platform_result.get("error_message") or platform_result.get("error", "不明")
                        row_data.append(f"エラー: {error}")
                else:
                    row_data.append("")  # 未アップロード

            # スプレッドシートに追加（2行目以降に追加）
            # シート名に特殊文字が含まれている場合に備えてクォート
            range_name = f"'{sheet_name}'!A2:Z2"
            body = {
                "values": [row_data]
            }
            
            print(f"   データを書き込み中...")
            print(f"   書き込むデータ: {row_data[:3]}...")  # 最初の3要素だけ表示
            
            result = service.spreadsheets().values().append(
                spreadsheetId=spreadsheet_id,
                range=range_name,
                valueInputOption="USER_ENTERED",
                insertDataOption="INSERT_ROWS",
                body=body
            ).execute()

            updated_cells = result.get('updates', {}).get('updatedCells', 0)
            print(f"✅ スプレッドシートに書き込み完了: {updated_cells} セル更新")
            print(f"   スプレッドシートURL: https://docs.google.com/spreadsheets/d/{spreadsheet_id}")
            return True

        except Exception as e:
            error_msg = str(e)
            print(f"❌ スプレッドシートへの書き込みエラー (試行 {attempt + 1}/{max_retries}): {error_msg}")
            
            # 最後の試行でない場合はリトライ
            if attempt < max_retries - 1:
                # 一時的なエラー（ネットワークエラーなど）の場合はリトライ
                if any(keyword in error_msg.lower() for keyword in ['timeout', 'connection', 'network', 'rate limit', 'quota']):
                    print(f"   → 一時的なエラーのためリトライします...")
                    continue
                else:
                    # その他のエラーもリトライを試みる
                    continue
            else:
                # 最後の試行でも失敗した場合
                import traceback
                print(f"   詳細: {traceback.format_exc()}")
                print(f"❌ 最大リトライ回数（{max_retries}回）に達しました")
                return False
    
    return False

def upload_video_to_all_sns(
    file_path: str,
    title: str,
    description: str,
    user: str,
    platforms: list,
    api_key: str,
    async_upload: bool = False,
    spreadsheet_id: str = None,
    sheet_name: str = "シート1",
):
    """
    Upload-Post APIを使用して複数のSNSプラットフォームに動画をアップロード
    
    参考: https://docs.upload-post.com/api/upload-video
    """
    if not os.path.exists(file_path):
        print(f"ERROR: 動画ファイルがありません: {file_path}")
        sys.exit(1)

    if not api_key:
        print("ERROR: UPLOAD_POST_API_KEY が設定されていません")
        print("環境変数または --api-key オプションで指定してください")
        print("APIキーは https://app.upload-post.com/api-keys で取得できます")
        sys.exit(1)

    if not user:
        print("ERROR: ユーザー名が指定されていません")
        print("--user オプションで指定してください")
        sys.exit(1)

    if not platforms:
        print("ERROR: プラットフォームが指定されていません")
        print("--platforms オプションで指定してください")
        sys.exit(1)

    print(f"▶ Upload-Post API を使用して {len(platforms)} プラットフォームにアップロード開始...")
    print(f"   プラットフォーム: {', '.join(platforms)}")

    headers = {
        "Authorization": f"Apikey {api_key}",
    }

    # ファイルをアップロード
    with open(file_path, "rb") as video_file:
        files = {
            "video": (os.path.basename(file_path), video_file, "video/mp4"),
        }

        # 全プラットフォーム共通: story_props.jsonから情報を取得してタイトルを生成
        meta = load_story_from_json(STORY_JSON_PATH)
        title_with_hashtags = build_title_with_hashtags(meta)

        data = {
            "user": user,
            "title": title_with_hashtags,  # デフォルトタイトルもタイトル＋ハッシュタグ（書籍名・著者名含む）に
        }
        
        # descriptionはX（Twitter）またはThreadsのみの場合は設定しない（titleに含まれるため）
        # 他のプラットフォーム（YouTube、Instagramなど）では必要
        if not (len(platforms) == 1 and (("twitter" in platforms or "x" in platforms) or "threads" in platforms)):
            data["description"] = description

        # プラットフォームを配列として追加（requestsではタプルのリストで送信）
        # 複数の同じキーを送信するために、タプルのリスト形式を使用
        # ドキュメント: https://docs.upload-post.com/api/upload-video
        # 注意: ドキュメントでは "twitter" と記載されているが、実際のAPIでは "x" を要求する
        # "twitter" が指定されている場合は "x" に変換
        normalized_platforms = ["x" if p == "twitter" else p for p in platforms]
        platform_data = [(f"platform[]", platform) for platform in normalized_platforms]

        # TikTok固有の設定
        if "tiktok" in platforms:
            # TikTok用のタイトルを生成（タイトル＋ハッシュタグ形式）
            data["tiktok_title"] = title_with_hashtags
            data["privacy_level"] = "PUBLIC_TO_EVERYONE"
            data["disable_duet"] = "false"
            data["disable_comment"] = "false"
            data["disable_stitch"] = "false"
            data["post_mode"] = "DIRECT_POST"
            # 動画の最初のフレーム（0秒）をサムネイルとして使用（本の画像が表示されている）
            # ドキュメント: cover_timestamp は Integer型、ミリ秒単位（デフォルト: 1000 = 1秒）
            # 0秒を指定するには 0（数値）を設定
            data["cover_timestamp"] = 500  # 0ミリ秒 = 動画の最初のフレーム
            # descriptionをコメントとして投稿（TikTokは概要欄がないため）
            # first_commentパラメータでコメントとして投稿
            # 注意: X（Twitter）やThreadsが含まれている場合は、first_commentがリプライになるため設定しない
            if "twitter" not in platforms and "x" not in platforms and "threads" not in platforms:
                data["first_comment"] = description

        # Instagram固有の設定
        if "instagram" in platforms:
            # タイトル＋ハッシュタグを設定
            data["instagram_title"] = title_with_hashtags
            data["media_type"] = "REELS"
            data["share_to_feed"] = "true"
            # 動画の最初のフレーム（0秒）をサムネイルとして使用
            # ドキュメント: thumb_offset は String型、タイムスタンプオフセット
            data["thumb_offset"] = "0"  # 0秒のフレームを使用

        # YouTube固有の設定
        if "youtube" in platforms:
            # タイトル＋ハッシュタグを設定
            data["youtube_title"] = build_youtube_title(meta)
            # YouTube用の説明文を設定（タイトルは含まない）
            youtube_description = build_youtube_description(meta)
            data["youtube_description"] = youtube_description
            # 書籍画像URLをサムネイルとして設定
            # 注意: YouTube Shortsにはカスタムサムネイル機能がサポートされていない可能性がありますが、
            # 試行として設定します（標準動画の場合は動作します）
            book_image_url = meta.get("book_image_url", "")
            if book_image_url:
                data["thumbnail_url"] = book_image_url
                print(f"   📸 YouTubeサムネイルURL設定: {book_image_url[:50]}...")
            else:
                print("   ⚠️ 書籍画像URLが見つかりません。サムネイルは設定されません。")

        # X (Twitter)固有の設定
        # ドキュメント: https://docs.upload-post.com/api/upload-video#x-twitter
        if "twitter" in platforms or "x" in platforms:
            # X用の説明文を生成（タイトルは含まない、【今回紹介した本はこちら】から始まり、ハッシュタグは最後）
            x_description = build_x_description(meta)
            # title パラメータに説明文を設定（タイトル部分は含めない）
            data["title"] = x_description
            # 成功したcurlコマンドに含まれていたX固有のパラメータを追加
            # 注意: requestsでは文字列として送信されるが、cURLでは引用符なしのブール値として送信する必要がある
            data["x_long_text_as_post"] = False  # スレッドとして投稿（false = スレッド、true = 1つの投稿）
            data["nullcast"] = False  # 通常の投稿（false = 通常、true = nullcast）
            data["for_super_followers_only"] = False  # 全フォロワーに公開（false = 全員、true = スーパーフォロワーのみ）
            data["share_with_followers"] = False  # フォロワーと共有しない（false = 共有しない、true = 共有する）
            # スレッドとして投稿するため、文字数制限は不要（自動的に280文字ごとに分割される）
            print(f"   📝 X（Twitter）タイトル文字数: {len(data['title'])}文字（自動的にスレッドとして分割されます）")

        # Threads固有の設定
        # ドキュメント: https://docs.upload-post.com/api/upload-video#threads
        if "threads" in platforms:
            # Threads用の説明文を生成（Xと同じ形式：タイトルは含まない、【今回紹介した本はこちら】から始まり、ハッシュタグは最後）
            threads_description = build_x_description(meta)
            # Threads用のタイトルを設定（Xと同じ説明文を使用）
            data["threads_title"] = threads_description
            # XとThreadsの両方が含まれている場合、Xの設定でtitleが上書きされているため、Threads用にも設定
            if "twitter" not in platforms and "x" not in platforms:
                # Xが含まれていない場合は、titleも設定
                data["title"] = threads_description
            print(f"   📝 Threadsタイトル文字数: {len(threads_description)}文字")

        # 非同期アップロードの設定
        # 成功したcurlコマンドでは常に async_upload=true が設定されていたため、常に "true" を設定
            data["async_upload"] = "true"

        # プラットフォームデータをdataに統合
        data_list = [(k, v) for k, v in data.items()] + platform_data

        # デバッグ: 実際に送信されるcURLコマンドを生成（APIキーはマスク）
        if "x" in normalized_platforms or "twitter" in platforms:
            print("\n📋 Debug: Generated cURL command (API key masked):")
            curl_parts = [f"curl -X POST {UPLOAD_POST_API_URL}"]
            curl_parts.append(f"  -H 'Authorization: Apikey [API_KEY_REMOVED]'")
            for key, value in data_list:
                if key == "video":
                    curl_parts.append(f"  -F 'video=@/path/to/video.mp4'")
                else:
                    # ブール値の場合は引用符なしで表示
                    if isinstance(value, bool):
                        curl_parts.append(f"  -F '{key}={str(value).lower()}'")
                    else:
                        # 文字列の場合はエスケープして引用符で囲む
                        escaped_value = str(value).replace('"', '\\"').replace('\n', '\\n')
                        curl_parts.append(f"  -F '{key}=\"{escaped_value}\"'")
            print("\n".join(curl_parts))
            print()

        try:
            response = requests.post(
                UPLOAD_POST_API_URL,
                headers=headers,
                files=files,
                data=data_list,
                timeout=300,
            )

            if response.status_code == 200:
                result = response.json()
                if result.get("success"):
                    if "request_id" in result:
                        # 非同期アップロード
                        request_id = result['request_id']
                        print("✅ アップロードが開始されました（非同期処理）")
                        print(f"📋 Request ID: {request_id}")
                        print("\n⏳ アップロード処理中...（バックグラウンドで処理されます）\n")
                        
                        # status確認はせず、リクエスト送信時点でスプレッドシートに書き込み
                        # 結果は空（アップロード完了後に手動で更新するか、後で確認する）
                        results = {}
                        
                        # スプレッドシートに書き込み（書籍名を使用）
                        spreadsheet_id_to_use = spreadsheet_id or SPREADSHEET_ID
                        if spreadsheet_id_to_use:
                            print("\n📊 スプレッドシートに書き込み中...")
                            # story_props.jsonから書籍名を取得
                            meta = load_story_from_json(STORY_JSON_PATH)
                            book_title = meta.get("book_title", title)  # 書籍名を優先、なければタイトル
                            success = write_to_spreadsheet(book_title, results, spreadsheet_id_to_use, sheet_name)
                            if not success:
                                print("⚠️ スプレッドシートへの書き込みに失敗しました")
                                print("   後で手動で書き込むか、write_to_spreadsheet.pyを使用してください")
                            else:
                                print(f"✅ スプレッドシートに書き込みました（Request ID: {request_id}）")
                                print(f"   アップロード完了後、以下のコマンドで結果を更新できます:")
                                print(f"   python write_to_spreadsheet.py --request-id {request_id}")
                        else:
                            print("⚠️ スプレッドシートIDが設定されていません。スキップします。")
                        
                        return result
                    else:
                        # 同期アップロード完了
                        print("🎉 アップロード完了！")
                        results = result.get("results", {})
                        
                        # resultsがリストの場合と辞書の場合の両方に対応
                        if isinstance(results, list):
                            # リストの場合は辞書に変換
                            results_dict = {}
                            for item in results:
                                if isinstance(item, dict):
                                    # プラットフォーム名を取得（platformキーがある場合）
                                    platform = item.get("platform", "unknown")
                                    results_dict[platform] = item
                            results = results_dict
                        
                        # 辞書として処理
                        if isinstance(results, dict):
                            for platform, platform_result in results.items():
                                if isinstance(platform_result, dict):
                                    if platform_result.get("success"):
                                        # URLは post_url キーを使用
                                        url = platform_result.get("post_url") or platform_result.get("url", "URL不明")
                                        print(f"  ✅ {platform.capitalize()}: {url}")
                                    else:
                                        # エラーメッセージは error_message キーを使用
                                        error = platform_result.get("error_message") or platform_result.get("error", "エラー不明")
                                        print(f"  ❌ {platform.capitalize()}: {error}")
                                        # X（Twitter）の403エラーの場合、詳細な対処方法を表示
                                        if platform.lower() in ["x", "twitter"] and "403" in str(error):
                                            print(f"\n   💡 X（Twitter）の403エラーの対処方法:")
                                            print(f"      1. Upload-PostのダッシュボードでXアカウントの再認証を試してください")
                                            print(f"         → https://app.upload-post.com/ にログインして「Profiles」セクションを確認")
                                            print(f"      2. Xアカウントに制限がかかっていないか確認してください")
                                            print(f"         → Xアプリで通常通りツイートできるか確認")
                                            print(f"      3. Xアカウントが2段階認証を有効にしている場合、Upload-Postで再認証が必要です")
                                            print(f"      4. プロファイル名（--user）が正しく設定されているか確認してください")
                        else:
                            print(f"  ⚠️ 予期しないresults形式: {results}")
                            # フォールバック: 空の辞書として扱う
                            results = {}
                        
                        # スプレッドシートに書き込み（書籍名を使用）- 確実に書き込むためリトライあり
                        spreadsheet_id_to_use = spreadsheet_id or SPREADSHEET_ID
                        if spreadsheet_id_to_use:
                            print("\n📊 スプレッドシートに書き込み中...")
                            # story_props.jsonから書籍名を取得
                            meta = load_story_from_json(STORY_JSON_PATH)
                            book_title = meta.get("book_title", title)  # 書籍名を優先、なければタイトル
                            success = write_to_spreadsheet(book_title, results, spreadsheet_id_to_use, sheet_name, max_retries=5)
                            if not success:
                                print("\n❌ スプレッドシートへの書き込みに失敗しました（最大リトライ回数に達しました）")
                                print("   以下のコマンドで手動で書き込むことができます:")
                                print(f"   python write_to_spreadsheet.py --title \"{book_title}\"", end="")
                                urls = []
                                if isinstance(results, dict):
                                    for platform, platform_result in results.items():
                                        if isinstance(platform_result, dict) and platform_result.get("success"):
                                            # URLは post_url キーを使用
                                            url = platform_result.get("post_url") or platform_result.get("url", "")
                                            urls.append(f"--{platform}-url {url}")
                                if urls:
                                    print(" " + " ".join(urls))
                                else:
                                    print()  # 改行を追加
                        else:
                            print("⚠️ スプレッドシートIDが設定されていません。スキップします。")
                        
                        return result
                else:
                    print(f"❌ アップロードエラー: {result.get('message', 'エラー不明')}")
                    sys.exit(1)

            elif response.status_code == 400:
                error = response.json()
                print(f"❌ リクエストエラー: {error.get('message', 'エラー不明')}")
                sys.exit(1)

            elif response.status_code == 401:
                print("❌ 認証エラー: APIキーが無効または期限切れです")
                print("   https://app.upload-post.com/api-keys でAPIキーを確認してください")
                sys.exit(1)

            elif response.status_code == 403:
                error = response.json()
                print(f"❌ アクセス拒否: {error.get('message', 'エラー不明')}")
                print("   プランの制限を確認してください")
                sys.exit(1)

            elif response.status_code == 404:
                error = response.json()
                print(f"❌ ユーザーが見つかりません: {error.get('message', 'エラー不明')}")
                sys.exit(1)

            elif response.status_code == 429:
                error = response.json()
                usage = error.get("usage", {})
                print(f"❌ 月間制限を超過: {error.get('message', 'エラー不明')}")
                print(f"   使用量: {usage.get('count')}/{usage.get('limit')}")
                sys.exit(1)

            else:
                print(f"❌ アップロードエラー: HTTP {response.status_code}")
                print(f"   レスポンス: {response.text}")
                sys.exit(1)

        except requests.exceptions.Timeout:
            print("❌ タイムアウト: アップロードに時間がかかりすぎました")
            sys.exit(1)
        except requests.exceptions.RequestException as e:
            print(f"❌ リクエストエラー: {e}")
            sys.exit(1)


def main():
    parser = argparse.ArgumentParser(
        description="Upload-Post APIを使用して複数のSNSに動画をアップロード",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用例:
  # 全てのプラットフォームにアップロード
  python upload_all_sns.py --user your_username --platforms tiktok instagram youtube

  # TikTokとInstagramのみ
  python upload_all_sns.py --user your_username --platforms tiktok instagram

  # 非同期アップロード
  python upload_all_sns.py --user your_username --platforms tiktok --async

参考:
  - APIドキュメント: https://docs.upload-post.com/api/upload-video
  - APIキー取得: https://app.upload-post.com/api-keys
        """,
    )
    parser.add_argument(
        "--file",
        "-f",
        default="out/book-summary.mp4",
        help="アップロードする動画ファイル",
    )
    parser.add_argument(
        "--user",
        "-u",
        default=os.getenv("UPLOAD_POST_USER", UPLOAD_POST_USER),
        help=f"Upload-Postのユーザー名（デフォルト: {UPLOAD_POST_USER}、環境変数 UPLOAD_POST_USER でも指定可能）",
    )
    parser.add_argument(
        "--platforms",
        "-p",
        nargs="+",
        default=["tiktok", "instagram", "youtube", "x", "threads"],
        choices=[
            "tiktok",
            "instagram",
            "linkedin",
            "youtube",
            "facebook",
            "twitter",
            "x",
            "threads",
            "pinterest",
            "bluesky",
        ],
        help="アップロードするプラットフォーム（複数指定可能、デフォルト: tiktok instagram youtube x threads）",
    )
    parser.add_argument(
        "--api-key",
        "-k",
        help="Upload-Post APIキー（環境変数 UPLOAD_POST_API_KEY でも指定可能）",
    )
    parser.add_argument(
        "--async",
        action="store_true",
        dest="async_upload",
        help="非同期アップロード（バックグラウンド処理）",
    )
    parser.add_argument(
        "--spreadsheet-id",
        "-s",
        default=SPREADSHEET_ID,
        help="GoogleスプレッドシートID（アップロード成功時にタイトルとURLを書き込み）",
    )
    parser.add_argument(
        "--sheet-name",
        default=SHEET_NAME,
        help=f"スプレッドシートのシート名（デフォルト: {SHEET_NAME}）",
    )

    args = parser.parse_args()

    api_key = args.api_key or UPLOAD_POST_API_KEY

    # ユーザー名が指定されていない場合のエラーチェック
    if not args.user or args.user.strip() == "":
        print("\n❌ エラー: ユーザー名（プロファイル名）が指定されていません\n")
        print("ユーザー名とは:")
        print("  Upload-Postのダッシュボードで設定したプロファイル名です")
        print("  各SNSアカウントを連携する際に設定した名前を指定してください\n")
        print("解決方法:")
        print("  1. --user オプションで指定:")
        print("     python upload_all_sns.py --user your_profile_name")
        print("  2. 環境変数で設定:")
        print("     export UPLOAD_POST_USER='your_profile_name'")
        print("     python upload_all_sns.py\n")
        print("参考: https://app.upload-post.com/ でプロファイル名を確認できます\n")
        return 1
    
    # ユーザー名の前後の空白を削除
    user = args.user.strip()

    meta = load_story_from_json(STORY_JSON_PATH)
    title = meta["title"]
    description = build_description(meta)

    try:
        upload_video_to_all_sns(
            file_path=args.file,
            title=title,
            description=description,
            user=user,
            platforms=args.platforms,
            api_key=api_key,
            async_upload=args.async_upload,
            spreadsheet_id=args.spreadsheet_id,
            sheet_name=args.sheet_name,
        )
        return 0
    except SystemExit as e:
        return e.code if e.code else 1
    except Exception as e:
        print(f"\n❌ 予期しないエラーが発生しました: {e}\n")
        return 1


if __name__ == "__main__":
    exit_code = main()
    if exit_code:
        sys.exit(exit_code)

