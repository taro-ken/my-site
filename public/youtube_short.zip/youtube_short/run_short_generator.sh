#!/bin/bash
# 汎用ショート自動生成スクリプト

# ここに手動で環境変数を入れたい場合は追加してください
# export OPENAI_API_KEY="sk-..."

# pythonスクリプトの実行
python3 run_short_generator.py
